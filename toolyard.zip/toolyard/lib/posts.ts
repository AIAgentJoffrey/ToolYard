export interface Post {
  slug: string;
  title: string;
  date: string;
  excerpt: string;
  content: string;
}

export const posts: Post[] = [
  {
    slug: 'finish-a-project-fast',
    title: 'Finish a project fast',
    date: '2025-08-05',
    excerpt: 'Tips on finishing your micro‑project quickly.',
    content: `## Finish a project fast\n\nSet a clear goal, use a template, and stick to a timebox. With ToolYard you can create something useful in minutes.`,
  },
  {
    slug: 'good-landing-page-sections',
    title: 'Good landing page sections',
    date: '2025-08-06',
    excerpt: 'What makes a great landing page?',
    content: `## Good landing page sections\n\nStart with a strong headline, follow up with benefits, social proof and a clear call to action. Our landing template covers these.`,
  },
  {
    slug: 'checklist-people-use',
    title: 'Checklist that people actually use',
    date: '2025-08-07',
    excerpt: 'Craft checklists that are clear and actionable.',
    content: `## Checklist that people actually use\n\nBreak tasks into small steps and keep the list focused. Our checklist template helps you get started.`,
  },
  {
    slug: 'write-mini-guide-30-min',
    title: 'Write a mini‑guide in 30 minutes',
    date: '2025-08-08',
    excerpt: 'How to produce helpful guides quickly.',
    content: `## Write a mini‑guide in 30 minutes\n\nOutline your sections, write concise tips, and publish. The mini guide template takes care of structure for you.`,
  },
  {
    slug: 'first-launch-day-checklist',
    title: 'Your first launch day checklist',
    date: '2025-08-09',
    excerpt: 'Don’t forget these steps when launching.',
    content: `## Your first launch day checklist\n\nPrepare your assets, tell your audience, and celebrate your launch! Use our event and checklist templates to plan it.`,
  },
];