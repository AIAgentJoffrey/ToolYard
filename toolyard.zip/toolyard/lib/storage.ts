export interface Project {
  id: string;
  name: string;
  templateSlug: string;
  data: Record<string, string>;
  updatedAt: number;
}

const STORAGE_KEY = 'ty_projects_v1';

function read(): Project[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Project[];
  } catch (err) {
    console.error('Failed to parse projects from storage', err);
    return [];
  }
}

function write(projects: Project[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
}

export function getProjects(): Project[] {
  return read().sort((a, b) => b.updatedAt - a.updatedAt);
}

export function saveProject(project: Project) {
  const projects = read();
  const idx = projects.findIndex((p) => p.id === project.id);
  if (idx >= 0) {
    projects[idx] = project;
  } else {
    projects.push(project);
  }
  write(projects);
}

export function deleteProject(id: string) {
  const projects = read().filter((p) => p.id !== id);
  write(projects);
}

export function duplicateProject(id: string): Project | null {
  const projects = read();
  const original = projects.find((p) => p.id === id);
  if (!original) return null;
  const copy: Project = {
    ...original,
    id: `${Date.now()}`,
    name: `${original.name} (copy)`,
    updatedAt: Date.now(),
  };
  projects.push(copy);
  write(projects);
  return copy;
}