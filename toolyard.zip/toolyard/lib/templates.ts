export interface TemplateSection {
  id: string;
  label: string;
  placeholder: string;
}

export interface Template {
  slug: string;
  title: string;
  tags: string[];
  description: string;
  sections: TemplateSection[];
  sampleData: Record<string, string>;
}

export const templates: Template[] = [
  {
    slug: 'landing-page',
    title: 'Landing Page',
    tags: ['landing', 'marketing'],
    description: 'A simple landing page to introduce your idea or product.',
    sections: [
      { id: 'hero', label: 'Hero', placeholder: 'Catchy headline and subheadline' },
      { id: 'features', label: 'Features', placeholder: 'List your main benefits' },
      { id: 'cta', label: 'Call to Action', placeholder: 'Tell visitors what to do next' },
    ],
    sampleData: {
      hero: 'Welcome to your amazing project!',
      features: '- Fast to build\n- Easy to share\n- Free forever',
      cta: 'Get started now',
    },
  },
  {
    slug: 'checklist',
    title: 'Checklist',
    tags: ['checklist'],
    description: 'Organize tasks into a simple checklist.',
    sections: [
      { id: 'intro', label: 'Introduction', placeholder: 'What is this checklist for?' },
      { id: 'items', label: 'Items', placeholder: 'List your tasks' },
    ],
    sampleData: {
      intro: 'Here is your quick checklist to stay on track.',
      items: '- [ ] Idea\n- [ ] Research\n- [ ] Build\n- [ ] Launch',
    },
  },
  {
    slug: 'mini-guide',
    title: 'Mini Guide',
    tags: ['guide'],
    description: 'Share knowledge in a concise guide.',
    sections: [
      { id: 'overview', label: 'Overview', placeholder: 'Give an overview' },
      { id: 'steps', label: 'Steps', placeholder: 'Step-by-step instructions' },
      { id: 'tips', label: 'Tips', placeholder: 'Helpful tips and resources' },
    ],
    sampleData: {
      overview: 'This guide will walk you through creating your first project.',
      steps: '1. Pick a template\n2. Edit content\n3. Publish',
      tips: 'Keep it short and clear.',
    },
  },
  {
    slug: 'seven-day-challenge',
    title: '7‑Day Challenge',
    tags: ['challenge'],
    description: 'Encourage readers to complete a small task each day.',
    sections: [
      { id: 'intro', label: 'Introduction', placeholder: 'Why take this challenge?' },
      { id: 'days', label: 'Days', placeholder: 'Describe each day’s task' },
    ],
    sampleData: {
      intro: 'Boost your productivity in a week!',
      days: '- Day 1: Plan\n- Day 2: Create\n- Day 3: Refine\n- Day 4: Share\n- Day 5: Improve\n- Day 6: Reflect\n- Day 7: Celebrate',
    },
  },
  {
    slug: 'newsletter-intro',
    title: 'Newsletter Intro',
    tags: ['newsletter'],
    description: 'Kick off your newsletter with a warm introduction.',
    sections: [
      { id: 'greeting', label: 'Greeting', placeholder: 'Welcome message' },
      { id: 'what-to-expect', label: 'What to expect', placeholder: 'Tell subscribers what they will get' },
    ],
    sampleData: {
      greeting: 'Hello friends!',
      'what-to-expect': 'Every week I’ll send you a short update with tips and resources.',
    },
  },
  {
    slug: 'course-outline',
    title: 'Course Outline',
    tags: ['course'],
    description: 'Outline your course or workshop.',
    sections: [
      { id: 'overview', label: 'Overview', placeholder: 'What is the course about?' },
      { id: 'modules', label: 'Modules', placeholder: 'List course modules or topics' },
      { id: 'outcomes', label: 'Outcomes', placeholder: 'What will learners achieve?' },
    ],
    sampleData: {
      overview: 'Learn to create and publish micro‑projects.',
      modules: '- Introduction\n- Planning\n- Building\n- Launching',
      outcomes: 'By the end, you’ll have published your own project!',
    },
  },
  {
    slug: 'book-list',
    title: 'Book List',
    tags: ['list'],
    description: 'Share a curated list of books with notes.',
    sections: [
      { id: 'intro', label: 'Introduction', placeholder: 'Why these books?' },
      { id: 'books', label: 'Books', placeholder: 'List your books and notes' },
    ],
    sampleData: {
      intro: 'My favourite reads for makers.',
      books: '- The Lean Startup – on validating ideas\n- Show Your Work – on sharing your process',
    },
  },
  {
    slug: 'resume-helper',
    title: 'Resume Helper',
    tags: ['resume'],
    description: 'Create a simple resume with sections.',
    sections: [
      { id: 'summary', label: 'Summary', placeholder: 'Short professional summary' },
      { id: 'experience', label: 'Experience', placeholder: 'List your experience' },
      { id: 'skills', label: 'Skills', placeholder: 'Highlight your skills' },
    ],
    sampleData: {
      summary: 'Product builder with a passion for micro‑projects.',
      experience: '- ToolYard Creator – 2025\n- Freelance Developer – 2023–2024',
      skills: 'React, Next.js, Tailwind CSS, UX design',
    },
  },
  {
    slug: 'resource-hub',
    title: 'Resource Hub',
    tags: ['resources'],
    description: 'Collect useful links and resources in one place.',
    sections: [
      { id: 'intro', label: 'Introduction', placeholder: 'Explain the hub’s purpose' },
      { id: 'links', label: 'Links', placeholder: 'List resources with notes' },
    ],
    sampleData: {
      intro: 'A hub of my favourite tools and articles.',
      links: '- [Next.js docs](https://nextjs.org) – official docs\n- [Tailwind CSS](https://tailwindcss.com) – styling library',
    },
  },
  {
    slug: 'roadmap',
    title: 'Roadmap',
    tags: ['planning'],
    description: 'Lay out milestones and planned work.',
    sections: [
      { id: 'vision', label: 'Vision', placeholder: 'Describe your long‑term vision' },
      { id: 'milestones', label: 'Milestones', placeholder: 'List key milestones' },
    ],
    sampleData: {
      vision: 'Create a collection of useful templates for everyone.',
      milestones: '- Q1: Launch MVP\n- Q2: Add more templates\n- Q3: Launch Pro plan',
    },
  },
  {
    slug: 'event-page',
    title: 'Event Page',
    tags: ['event'],
    description: 'Promote your event with essential info.',
    sections: [
      { id: 'about', label: 'About the event', placeholder: 'What is the event?' },
      { id: 'agenda', label: 'Agenda', placeholder: 'Schedule or activities' },
      { id: 'register', label: 'How to register', placeholder: 'Sign‑up instructions' },
    ],
    sampleData: {
      about: 'Join us for a day of making and sharing.',
      agenda: '- 10:00 – Introduction\n- 11:00 – Workshops\n- 14:00 – Showcase',
      register: 'Sign up at example.com',
    },
  },
  {
    slug: 'about-me',
    title: 'About Me',
    tags: ['about'],
    description: 'Create a personal bio page.',
    sections: [
      { id: 'bio', label: 'Bio', placeholder: 'Tell your story' },
      { id: 'projects', label: 'Projects', placeholder: 'Highlight your work' },
      { id: 'contact', label: 'Contact', placeholder: 'How can people reach you?' },
    ],
    sampleData: {
      bio: 'I’m a builder who loves making useful tools.',
      projects: '- ToolYard – micro‑project platform\n- Blog – writing about productivity',
      contact: 'Email me at you@example.com',
    },
  },
];