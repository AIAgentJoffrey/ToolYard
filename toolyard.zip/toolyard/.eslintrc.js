module.exports = {
  root: true,
  // Extend the recommended Next.js ESLint configs. We intentionally
  // avoid extending "prettier" here because Vercel's build environment
  // does not install the prettier config in this nested package. The
  // Prettier setup lives in the root package instead, so eslint will
  // still respect formatting rules without failing the build.
  extends: ["next", "next/core-web-vitals"],
};