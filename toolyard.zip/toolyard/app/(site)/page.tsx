import Link from 'next/link';

export const metadata = {
  title: 'ToolYard – Create something useful today',
  description: 'Pick a template, fill the blanks, publish in minutes.',
};

export default function HomePage() {
  const bannerPending = process.env.NEXT_PUBLIC_DOMAIN_PENDING === 'true';
  return (
    <section className="text-center space-y-6">
      {bannerPending && (
        <div className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded-md">
          Custom domain review pending, using temporary URL.
        </div>
      )}
      <h1 className="text-4xl md:text-5xl font-bold">
        Create something useful today.
      </h1>
      <p className="text-lg md:text-xl text-gray-700">
        Pick a template, fill the blanks, publish in minutes.
      </p>
      <div className="flex flex-col md:flex-row justify-center gap-4 pt-4">
        <Link
          href="/templates"
          className="px-6 py-3 bg-brand-accent text-white rounded-md shadow hover:bg-brand-primary transition"
        >
          Browse Templates
        </Link>
        <Link
          href="/create"
          className="px-6 py-3 bg-brand-primary text-white rounded-md shadow hover:bg-brand-accent transition"
        >
          Start Creating
        </Link>
      </div>
    </section>
  );
}