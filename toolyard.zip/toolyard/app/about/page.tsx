export const metadata = {
  title: 'About – ToolYard',
  description: 'Learn about ToolYard and why it exists.',
};

export default function AboutPage() {
  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">About</h1>
      <p>
        ToolYard is a simple platform to help you create and publish useful
        micro‑projects quickly. We believe that everyone should be able to
        share their ideas without friction.
      </p>
      <p>
        Our mission is to provide a library of templates and a friendly editor
        so you can focus on your content, not the tooling. Whether you’re
        launching a small landing page, writing a guide or compiling a
        checklist, ToolYard is here to help.
      </p>
      <p>
        Built with ❤️ in Sofia.
      </p>
    </section>
  );
}