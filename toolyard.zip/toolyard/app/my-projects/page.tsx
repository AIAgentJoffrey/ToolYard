import MyProjectsContent from './MyProjectsContent';

// Metadata for the My Projects page. Defining this here allows the page
// to remain a server component while the interactive content lives in
// a separate client component. Titles and descriptions are important
// for SEO and shareability.
export const metadata = {
  title: 'My Projects',
  description: 'View and manage your ToolYard projects saved in your browser.',
};

export default function MyProjectsPage() {
  return <MyProjectsContent />;
}