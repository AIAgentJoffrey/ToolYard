export const metadata = {
  title: 'Pricing – ToolYard',
  description: 'Free for now. Pro later with extra features.',
};

export default function PricingPage() {
  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Pricing</h1>
      <p>
        Free for now. Pro later (custom domain, no badge, extra exports).
      </p>
      <div className="grid md:grid-cols-2 gap-6">
        <div className="border border-gray-200 rounded-lg p-6 bg-white">
          <h2 className="text-xl font-semibold mb-2">Free</h2>
          <p className="mb-4 text-gray-700">Everything you need to start.</p>
          <ul className="space-y-2 list-disc list-inside text-gray-600">
            <li>12 templates</li>
            <li>4‑step wizard</li>
            <li>Local storage projects</li>
            <li>Public share URLs</li>
          </ul>
        </div>
        <div className="border border-gray-200 rounded-lg p-6 bg-white opacity-60 cursor-not-allowed">
          <h2 className="text-xl font-semibold mb-2">Pro (coming soon)</h2>
          <p className="mb-4 text-gray-700">
            Unlock more features and support ToolYard.
          </p>
          <ul className="space-y-2 list-disc list-inside text-gray-600">
            <li>Custom domain</li>
            <li>No ToolYard badge</li>
            <li>Extra export formats</li>
            <li>And more!</li>
          </ul>
        </div>
      </div>
    </section>
  );
}