import { notFound } from 'next/navigation';
import Link from 'next/link';
import { posts } from '@/lib/posts';

interface Props {
  params: { slug: string };
}

export function generateStaticParams() {
  return posts.map((post) => ({ slug: post.slug }));
}

export function generateMetadata({ params }: Props) {
  const post = posts.find((p) => p.slug === params.slug);
  return {
    title: post ? `${post.title} – Blog – ToolYard` : undefined,
    description: post?.excerpt,
  };
}

export default function BlogPostPage({ params }: Props) {
  const idx = posts.findIndex((p) => p.slug === params.slug);
  const post = posts[idx];
  if (!post) {
    notFound();
  }
  const prev = idx > 0 ? posts[idx - 1] : null;
  const next = idx < posts.length - 1 ? posts[idx + 1] : null;
  return (
    <article className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">{post.title}</h1>
      <p className="text-xs text-gray-500">
        {new Date(post.date).toLocaleDateString()}
      </p>
      <div className="prose prose-gray max-w-none">
        {post.content
          .split(/\n\n+/)
          .map((para, idx) => (
            <p key={idx} dangerouslySetInnerHTML={{ __html: para }} />
          ))}
      </div>
      <nav className="flex justify-between text-sm pt-8">
        {prev ? (
          <Link href={`/blog/${prev.slug}`} className="text-brand-primary hover:underline">
            ← {prev.title}
          </Link>
        ) : <span />}
        {next ? (
          <Link href={`/blog/${next.slug}`} className="text-brand-primary hover:underline">
            {next.title} →
          </Link>
        ) : <span />}
      </nav>
    </article>
  );
}