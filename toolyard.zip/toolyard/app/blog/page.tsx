import { posts } from '@/lib/posts';
import Link from 'next/link';

export const metadata = {
  title: 'Blog – ToolYard',
  description: 'Helpful posts about creating micro‑projects.',
};

export default function BlogIndex() {
  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Blog</h1>
      <div className="space-y-6">
        {posts.map((post) => (
          <article key={post.slug} className="border-b pb-4">
            <h2 className="text-2xl font-semibold mb-1">
              <Link href={`/blog/${post.slug}`} className="hover:text-brand-primary">
                {post.title}
              </Link>
            </h2>
            <p className="text-xs text-gray-500 mb-1">
              {new Date(post.date).toLocaleDateString()}
            </p>
            <p className="text-gray-700">{post.excerpt}</p>
          </article>
        ))}
      </div>
    </section>
  );
}