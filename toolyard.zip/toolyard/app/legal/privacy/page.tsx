export const metadata = {
  title: 'Privacy Policy – ToolYard',
  description: 'Privacy policy for ToolYard.',
};

export default function PrivacyPage() {
  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Privacy Policy</h1>
      <p>
        We don’t collect personal data. All your projects stay in your browser.
        If we enable analytics, we anonymise IP and respect Do Not Track.
      </p>
      <p>
        Contact us if you have any questions about privacy.
      </p>
    </section>
  );
}