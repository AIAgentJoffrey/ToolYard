export const metadata = {
  title: 'Terms of Service – ToolYard',
  description: 'Terms of service for ToolYard.',
};

export default function TermsPage() {
  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Terms of Service</h1>
      <p>
        By using ToolYard you agree to use it responsibly and not abuse the
        platform. The service is provided as‑is without warranty. We reserve
        the right to modify or discontinue the service.
      </p>
      <p>
        If you have questions about these terms, please contact us.
      </p>
    </section>
  );
}