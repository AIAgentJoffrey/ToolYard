import { notFound } from 'next/navigation';
import Link from 'next/link';
import { templates } from '@/lib/templates';

interface Props {
  params: { slug: string };
}

export async function generateStaticParams() {
  return templates.map((tpl) => ({ slug: tpl.slug }));
}

export function generateMetadata({ params }: Props) {
  const template = templates.find((t) => t.slug === params.slug);
  if (!template) return {};
  return {
    title: `${template.title} – Template – ToolYard`,
    description: template.description,
  };
}

export default function TemplateDetail({ params }: Props) {
  const template = templates.find((t) => t.slug === params.slug);
  if (!template) {
    notFound();
  }
  return (
    <article className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-2">{template!.title}</h1>
      <p className="text-gray-600 mb-4">{template!.description}</p>
      <div className="space-y-4 mb-6">
        {template!.sections.map((section) => (
          <div key={section.id} className="border border-gray-200 rounded-md p-4 bg-white">
            <h3 className="font-semibold mb-1">{section.label}</h3>
            <p className="text-gray-700 whitespace-pre-wrap">
              {template!.sampleData[section.id] || ''}
            </p>
          </div>
        ))}
      </div>
      <Link
        href={`/create?template=${template!.slug}`}
        className="inline-block px-5 py-3 bg-brand-primary text-white rounded-md shadow hover:bg-brand-accent transition"
      >
        Use this template
      </Link>
    </article>
  );
}