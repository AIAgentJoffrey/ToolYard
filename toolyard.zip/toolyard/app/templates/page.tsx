"use client";
import { useState, useMemo } from 'react';
import { templates } from '@/lib/templates';
import { TemplateCard } from '@/components/TemplateCard';

// Removed metadata export to comply with Next.js rules. Metadata can be defined in a parent layout.

export default function TemplatesPage() {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('');

  const filtered = useMemo(() => {
    return templates.filter((tpl) => {
      const matchesQuery = tpl.title
        .toLowerCase()
        .includes(query.toLowerCase()) ||
        tpl.tags.some((tag) => tag.toLowerCase().includes(query.toLowerCase()));
      const matchesFilter = filter ? tpl.tags.includes(filter) : true;
      return matchesQuery && matchesFilter;
    });
  }, [query, filter]);

  const uniqueTags = Array.from(
    new Set(templates.flatMap((tpl) => tpl.tags))
  );

  return (
    <section>
      <h1 className="text-3xl font-bold mb-4">Templates</h1>
      <div className="mb-4 flex flex-col md:flex-row items-center gap-4">
        <input
          type="search"
          placeholder="Search templates..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full md:w-1/2 px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary"
        />
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary"
        >
          <option value="">All Types</option>
          {uniqueTags.map((tag) => (
            <option key={tag} value={tag}>
              {tag}
            </option>
          ))}
        </select>
      </div>
      {filtered.length === 0 ? (
        <p className="text-gray-600">No templates found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((tpl) => (
            <TemplateCard key={tpl.slug} template={tpl} />
          ))}
        </div>
      )}
    </section>
  );
}