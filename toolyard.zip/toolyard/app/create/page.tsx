import { Suspense } from 'react';
import CreatePageContent from './CreatePageContent';

// Metadata for the Create page. Since this file is a server component (no
// `use client` directive), we can export metadata here safely.
export const metadata = {
  title: 'Create a Project',
  description: 'Use our wizard to craft a new ToolYard project from a template.',
};

/**
 * Server component wrapper for the create page. This component simply
 * renders the client-side wizard within a Suspense boundary to satisfy
 * Next.js requirements around hooks like useSearchParams(). A fallback
 * loading state is shown while the client chunk loads.
 */
export default function CreatePage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <CreatePageContent />
    </Suspense>
  );
}