"use client";
import { useSearchParams, useRouter } from 'next/navigation';
import { useState, useEffect, useMemo } from 'react';
import { templates } from '@/lib/templates';
import { saveProject, Project } from '@/lib/storage';
import { event as gaEvent } from '@/lib/analytics';
import Link from 'next/link';

export const metadata = {
  title: 'Create – ToolYard',
  description: 'Create a new project from a template.',
};

export default function CreatePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const templateSlug = searchParams.get('template') || '';
  const template = useMemo(
    () => templates.find((t) => t.slug === templateSlug),
    [templateSlug]
  );

  // Step state
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [audience, setAudience] = useState('');
  const [sectionIds, setSectionIds] = useState<string[]>([]);
  const [content, setContent] = useState<Record<string, string>>({});

  // Prefill sections from template on mount
  useEffect(() => {
    if (template) {
      setSectionIds(template.sections.map((s) => s.id));
      const initialContent: Record<string, string> = {};
      template.sections.forEach((s) => {
        initialContent[s.id] = template.sampleData[s.id] || '';
      });
      setContent(initialContent);
    }
  }, [template]);

  // Autosave draft to localStorage
  useEffect(() => {
    const draft: Project = {
      id: 'draft',
      name,
      templateSlug: templateSlug || '',
      data: content,
      updatedAt: Date.now(),
    };
    saveProject(draft);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, audience, sectionIds, content]);

  const currentSections = template?.sections.filter((s) => sectionIds.includes(s.id)) || [];

  // Encode project data to Base64 for publishing
  const encodedData = useMemo(() => {
    const payload = {
      name,
      template: templateSlug,
      sections: sectionIds,
      content,
    };
    try {
      return Buffer.from(JSON.stringify(payload)).toString('base64');
    } catch {
      return '';
    }
  }, [name, templateSlug, sectionIds, content]);

  function handleToggleSection(id: string) {
    setSectionIds((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  }

  function handlePublish() {
    const id = Date.now().toString(36);
    const project: Project = {
      id,
      name: name || template?.title || 'Untitled',
      templateSlug: templateSlug || '',
      data: content,
      updatedAt: Date.now(),
    };
    saveProject(project);
    gaEvent('publish_project', { template: templateSlug });
    router.push(`/p/${id}#data=${encodedData}`);
  }

  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Create your project</h1>
      {/* Steps navigation */}
      <div className="flex items-center space-x-2">
        {[1, 2, 3, 4].map((i) => (
          <button
            key={i}
            onClick={() => setStep(i)}
            className={`w-8 h-8 rounded-full border flex items-center justify-center text-sm ${
              step === i ? 'bg-brand-primary text-white' : 'bg-white text-gray-700'
            }`}
          >
            {i}
          </button>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-4">
          <div>
            <label className="block mb-1 font-medium">Project name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. My New Project"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary"
            />
          </div>
          <div>
            <label className="block mb-1 font-medium">Audience (optional)</label>
            <input
              type="text"
              value={audience}
              onChange={(e) => setAudience(e.target.value)}
              placeholder="Who is this for?"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary"
            />
          </div>
          <div className="flex justify-end">
            <button
              onClick={() => setStep(2)}
              className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {step === 2 && template && (
        <div className="space-y-4">
          <h2 className="font-semibold">Sections</h2>
          <p className="text-sm text-gray-600 mb-2">
            Toggle which sections you want to include.
          </p>
          <div className="space-y-2">
            {template.sections.map((s) => (
              <label key={s.id} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={sectionIds.includes(s.id)}
                  onChange={() => handleToggleSection(s.id)}
                />
                <span>{s.label}</span>
              </label>
            ))}
          </div>
          <div className="flex justify-between pt-4">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 rounded-md bg-gray-200 hover:bg-gray-300"
            >
              Back
            </button>
            <button
              onClick={() => setStep(3)}
              className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4">
          {currentSections.map((s) => (
            <div key={s.id} className="space-y-1">
              <label className="font-medium">{s.label}</label>
              <textarea
                value={content[s.id] || ''}
                onChange={(e) => setContent({ ...content, [s.id]: e.target.value })}
                placeholder={s.placeholder}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary min-h-[120px]"
              />
            </div>
          ))}
          <div className="flex justify-between pt-4">
            <button
              onClick={() => setStep(2)}
              className="px-4 py-2 rounded-md bg-gray-200 hover:bg-gray-300"
            >
              Back
            </button>
            <button
              onClick={() => setStep(4)}
              className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-4">
          <h2 className="font-semibold">Preview</h2>
          <div className="space-y-3 border border-gray-200 rounded-md p-4 bg-white">
            {currentSections.map((s) => (
              <div key={s.id}>
                <h3 className="font-semibold mb-1">{s.label}</h3>
                <p className="whitespace-pre-wrap text-gray-700">
                  {content[s.id] || ''}
                </p>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            <button
              onClick={handlePublish}
              className="w-full px-5 py-3 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Publish
            </button>
            <button
              onClick={() => {
                const json = JSON.stringify({ name, template: templateSlug, sections: sectionIds, content });
                navigator.clipboard.writeText(json);
                gaEvent('export_file', { type: 'json' });
                alert('JSON copied to clipboard');
              }}
              className="w-full px-5 py-3 bg-brand-muted text-gray-800 rounded-md hover:bg-brand-primary hover:text-white"
            >
              Copy JSON
            </button>
          </div>
          <div className="flex justify-between pt-4">
            <button
              onClick={() => setStep(3)}
              className="px-4 py-2 rounded-md bg-gray-200 hover:bg-gray-300"
            >
              Back
            </button>
          </div>
        </div>
      )}
    </section>
  );
}