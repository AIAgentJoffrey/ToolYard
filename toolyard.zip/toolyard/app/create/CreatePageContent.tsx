"use client";

import { useSearchParams, useRouter } from 'next/navigation';
import { useState, useEffect, useMemo } from 'react';
import { templates } from '@/lib/templates';
import { saveProject, Project } from '@/lib/storage';
import { event as gaEvent } from '@/lib/analytics';
import Link from 'next/link';

/**
 * Client component containing the entire create‑project wizard. This is split
 * out from the server page so that hooks like useSearchParams can be used
 * safely. The server component simply wraps this in a Suspense boundary.
 */
export default function CreatePageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const templateSlug = searchParams.get('template') || '';
  const template = useMemo(
    () => templates.find((t) => t.slug === templateSlug),
    [templateSlug]
  );

  // Step state
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [audience, setAudience] = useState('');
  const [sectionIds, setSectionIds] = useState<string[]>([]);
  const [content, setContent] = useState<Record<string, string>>({});

  // Prefill sections from template on mount
  useEffect(() => {
    if (template) {
      setSectionIds(template.sections.map((s) => s.id));
      const initialContent: Record<string, string> = {};
      template.sections.forEach((s) => {
        initialContent[s.id] = template.sampleData[s.id] || '';
      });
      setContent(initialContent);
    }
  }, [template]);

  // Autosave draft to localStorage
  useEffect(() => {
    const draft: Project = {
      id: 'draft',
      name,
      title: name, // alias title to name for backward compatibility
      description: '',
      templateSlug: templateSlug || '',
      data: content,
      updatedAt: Date.now(),
    };
    saveProject(draft);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, audience, sectionIds, content]);

  const currentSections =
    template?.sections.filter((s) => sectionIds.includes(s.id)) || [];

  // Encode project data to Base64 for publishing
  const encodedData = useMemo(() => {
    const payload = {
      name,
      template: templateSlug,
      sections: sectionIds,
      content,
    };
    try {
      return Buffer.from(JSON.stringify(payload)).toString('base64');
    } catch {
      return '';
    }
  }, [name, templateSlug, sectionIds, content]);

  function handleToggleSection(id: string) {
    setSectionIds((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  }

  function handlePublish() {
    const id = Date.now().toString(36);
    const project: Project = {
      id,
      name: name || template?.title || 'Untitled',
      title: name || template?.title || 'Untitled',
      description: '',
      templateSlug: templateSlug || '',
      data: content,
      updatedAt: Date.now(),
    };
    saveProject(project);
    gaEvent('publish_project', { template: templateSlug });
    router.push(`/p/${id}#data=${encodedData}`);
  }

  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Create your project</h1>
      {/* Steps navigation */}
      <div className="flex items-center space-x-2">
        {[1, 2, 3, 4].map((i) => (
          <button
            key={i}
            onClick={() => setStep(i)}
            className={`w-8 h-8 rounded-full border flex items-center justify-center text-sm ${
              step === i
                ? 'bg-brand-primary text-white'
                : 'bg-white text-gray-700'
            }`}
          >
            {i}
          </button>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-4">
          <div>
            <label className="block mb-1 font-medium">Project name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. My New Project"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary"
            />
          </div>
          <div>
            <label className="block mb-1 font-medium">Audience (optional)</label>
            <input
              type="text"
              value={audience}
              onChange={(e) => setAudience(e.target.value)}
              placeholder="Who is this for?"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary"
            />
          </div>
          <div className="flex justify-end">
            <button
              onClick={() => setStep(2)}
              className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {step === 2 && template && (
        <div className="space-y-4">
          <h2 className="font-semibold">Sections</h2>
          <p className="text-sm text-gray-600 mb-2">
            Toggle which sections you want to include.
          </p>
          <div className="space-y-2">
            {template.sections.map((s) => (
              <label key={s.id} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={sectionIds.includes(s.id)}
                  onChange={() => handleToggleSection(s.id)}
                />
                <span>{s.label}</span>
              </label>
            ))}
          </div>
          <div className="flex justify-between pt-4">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 rounded-md bg-gray-200 hover:bg-gray-300"
            >
              Back
            </button>
            <button
              onClick={() => setStep(3)}
              className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4">
          {currentSections.map((s) => (
            <div key={s.id} className="space-y-1">
              <label className="font-medium">{s.label}</label>
              <textarea
                value={content[s.id] || ''}
                onChange={(e) => setContent({ ...content, [s.id]: e.target.value })}
                placeholder={s.placeholder}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-brand-primary focus:border-brand-primary min-h-[120px]"
              />
            </div>
          ))}
          <div className="flex justify-between pt-4">
            <button
              onClick={() => setStep(2)}
              className="px-4 py-2 rounded-md bg-gray-200 hover:bg-gray-300"
            >
              Back
            </button>
            <button
              onClick={() => setStep(4)}
              className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-4">
          <h2 className="font-semibold">Preview & Publish</h2>
          <p className="text-sm text-gray-600">
            Review your content and publish or export your project.
          </p>
          <div className="border p-4 rounded-md">
            <h3 className="text-xl font-semibold mb-2">
              {name || template?.title || 'Untitled'}
            </h3>
            {currentSections.map((s) => (
              <div key={s.id} className="mb-3">
                <h4 className="font-medium mb-1">{s.label}</h4>
                <p className="whitespace-pre-wrap break-words">
                  {content[s.id] || ''}
                </p>
              </div>
            ))}
          </div>
          <div className="flex justify-between pt-4">
            <button
              onClick={() => setStep(3)}
              className="px-4 py-2 rounded-md bg-gray-200 hover:bg-gray-300"
            >
              Back
            </button>
            <div className="space-x-2">
              <button
                onClick={handlePublish}
                className="px-5 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-accent"
              >
                Publish
              </button>
              <button
                onClick={() => {
                  // Export HTML
                  const blob = new Blob([
                    '<!DOCTYPE html><html><head><meta charset="UTF-8" /><title>' +
                      (name || 'Untitled') +
                      '</title></head><body>' +
                      currentSections
                        .map(
                          (s) =>
                            `<h3>${s.label}</h3><p>${
                              content[s.id] || ''
                            }</p>`
                        )
                        .join('') +
                      '</body></html>',
                  ], { type: 'text/html' });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `${name || 'project'}.html`;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  gaEvent('export_file', { type: 'html' });
                }}
                className="px-5 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
              >
                Export HTML
              </button>
              <button
                onClick={() => {
                  // Export Markdown
                  const md = currentSections
                    .map((s) => `## ${s.label}\n\n${content[s.id] || ''}`)
                    .join('\n\n');
                  const blob = new Blob([md], { type: 'text/markdown' });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `${name || 'project'}.md`;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  gaEvent('export_file', { type: 'markdown' });
                }}
                className="px-5 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
              >
                Export MD
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}