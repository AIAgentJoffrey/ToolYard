"use client";
import { useEffect, useState } from 'react';
import { Footer } from '@/components/Footer';
import { Project, getProjects } from '@/lib/storage';

interface Props {
  params: { id: string };
}

export default function PublicPage({ params }: Props) {
  const { id } = params;
  const [payload, setPayload] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const hash = window.location.hash;
      if (hash.startsWith('#data=')) {
        const encoded = hash.slice(6);
        const json = JSON.parse(atob(encoded));
        setPayload(json);
      } else {
        // Try to load from localStorage
        const existing = getProjects().find((p) => p.id === id);
        if (existing) {
          setPayload({
            name: existing.name,
            template: existing.templateSlug,
            sections: Object.keys(existing.data),
            content: existing.data,
          });
        }
      }
    } catch (err) {
      console.error('Failed to load payload', err);
    } finally {
      setLoading(false);
    }
  }, [id]);

  if (loading) return <p>Loading...</p>;
  if (!payload) return <p>Project not found.</p>;

  return (
    <div className="min-h-screen flex flex-col items-center px-4 md:px-8 py-8">
      <article className="max-w-2xl w-full space-y-6">
        <h1 className="text-3xl font-bold mb-2">{payload.name || 'Untitled'}</h1>
        {payload.sections.map((id: string) => (
          <section key={id} className="space-y-1">
            <h2 className="text-xl font-semibold capitalize">
              {id.replace(/-/g, ' ')}
            </h2>
            <p className="whitespace-pre-wrap text-gray-700">
              {payload.content[id]}
            </p>
          </section>
        ))}
      </article>
      <div className="mt-8 w-full">
        <Footer showBadge={true} />
      </div>
    </div>
  );
}