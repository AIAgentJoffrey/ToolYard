import Link from 'next/link';
import type { Template } from '@/lib/templates';

export function TemplateCard({ template }: { template: Template }) {
  return (
    <div className="p-4 rounded-lg shadow-sm bg-white border border-gray-200 hover:shadow-md transition">
      <h3 className="text-xl font-semibold mb-2">{template.title}</h3>
      <p className="text-sm text-gray-600 mb-4">{template.description}</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {template.tags.map((tag) => (
          <span
            key={tag}
            className="text-xs px-2 py-1 bg-brand-muted rounded-full text-gray-700"
          >
            {tag}
          </span>
        ))}
      </div>
      <Link
        href={`/templates/${template.slug}`}
        className="inline-block text-sm font-medium text-brand-primary hover:text-brand-accent"
      >
        View details
      </Link>
    </div>
  );
}