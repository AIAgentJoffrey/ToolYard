'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const navItems = [
  { href: '/templates', label: 'Templates' },
  { href: '/create', label: 'Create' },
  { href: '/my-projects', label: 'My Projects' },
  { href: '/blog', label: 'Blog' },
  { href: '/pricing', label: 'Pricing' },
  { href: '/about', label: 'About' },
];

export function Header() {
  const pathname = usePathname();
  return (
    <header className="w-full py-4 px-6 flex items-center justify-between">
      <Link href="/" className="text-2xl font-bold text-brand-primary">
        ToolYard
      </Link>
      <nav className="hidden md:flex space-x-4">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`px-3 py-1 rounded-md text-sm font-medium ${
              pathname?.startsWith(item.href)
                ? 'bg-brand-primary text-white'
                : 'hover:bg-brand-muted'
            }`}
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}