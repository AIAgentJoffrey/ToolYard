import Link from 'next/link';

export function Footer({ showBadge = true }: { showBadge?: boolean }) {
  return (
    <footer className="w-full py-8 px-6 text-sm text-center space-y-2">
      {showBadge && (
        <div className="text-xs text-gray-600">
          Made with{' '}
          <Link href="/" className="underline hover:text-brand-primary">
            ToolYard
          </Link>
        </div>
      )}
      <div className="flex flex-wrap justify-center gap-x-4 gap-y-2 text-gray-600">
        <Link href="/pricing" className="hover:text-brand-primary">
          Pricing
        </Link>
        <Link href="/about" className="hover:text-brand-primary">
          About
        </Link>
        <Link href="/blog" className="hover:text-brand-primary">
          Blog
        </Link>
        <Link href="/legal/privacy" className="hover:text-brand-primary">
          Privacy
        </Link>
        <Link href="/legal/terms" className="hover:text-brand-primary">
          Terms
        </Link>
      </div>
    </footer>
  );
}