"use client";
import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  getProjects,
  deleteProject,
  duplicateProject,
  Project,
} from '@/lib/storage';


// Note: Metadata is defined in the parent route file for this page.  
// Since this page is a client component (uses "use client"), we cannot
// export a `metadata` object here. The metadata for the My Projects page
// is instead provided by the parent layout.

export default function MyProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    setProjects(getProjects());
  }, []);

  function handleDelete(id: string) {
    if (confirm('Delete this project?')) {
      deleteProject(id);
      setProjects(getProjects());
    }
  }

  function handleDuplicate(id: string) {
    const copy = duplicateProject(id);
    if (copy) setProjects(getProjects());
  }

  return (
    <section className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">My Projects</h1>
      {projects.length === 0 ? (
        <p className="text-gray-600">No projects saved yet. Start creating!</p>
      ) : (
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b">
              <th className="py-2">Name</th>
              <th className="py-2">Updated</th>
              <th className="py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project) => (
              <tr key={project.id} className="border-b hover:bg-gray-50">
                <td className="py-2">
                  <Link href={`/p/${project.id}`} className="text-brand-primary hover:underline">
                    {project.name}
                  </Link>
                </td>
                <td className="py-2 text-sm text-gray-600">
                  {new Date(project.updatedAt).toLocaleString()}
                </td>
                <td className="py-2 text-right space-x-2">
                  <button
                    onClick={() => handleDuplicate(project.id)}
                    className="text-sm px-2 py-1 bg-gray-200 rounded hover:bg-gray-300"
                  >
                    Duplicate
                  </button>
                  <button
                    onClick={() => handleDelete(project.id)}
                    className="text-sm px-2 py-1 bg-red-200 text-red-800 rounded hover:bg-red-300"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}