"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  getProjects,
  deleteProject,
  duplicateProject,
  Project,
} from '@/lib/storage';

// This client component contains the interactive logic for the
// "My Projects" page. Keeping it in a separate file allows the
// page itself to remain a server component and export metadata.

export default function MyProjectsContent() {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    setProjects(getProjects());
  }, []);

  function handleDelete(id: string) {
    if (confirm('Delete this project?')) {
      deleteProject(id);
      setProjects(getProjects());
    }
  }

  function handleDuplicate(id: string) {
    const copy = duplicateProject(id);
    if (copy) setProjects(getProjects());
  }

  return (
    <section className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">My Projects</h1>
      {projects.length === 0 ? (
        <p className="text-gray-600">No projects saved yet. Start creating!</p>
      ) : (
        <ul className="space-y-2">
          {projects.map((proj) => (
            <li
              key={proj.id}
              className="border rounded-lg p-4 flex items-start justify-between hover:shadow-md transition"
            >
              <div className="flex-1 pr-4">
                <h2 className="font-semibold text-lg">{proj.title}</h2>
                <p className="text-sm text-gray-600 truncate">
                  {proj.description || 'No description provided.'}
                </p>
              </div>
              <div className="flex space-x-2 items-center">
                <Link
                  href={`/create?draft=${proj.id}`}
                  className="text-blue-600 hover:underline text-sm"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handleDuplicate(proj.id)}
                  className="text-green-600 hover:underline text-sm"
                >
                  Duplicate
                </button>
                <button
                  onClick={() => handleDelete(proj.id)}
                  className="text-red-600 hover:underline text-sm"
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}